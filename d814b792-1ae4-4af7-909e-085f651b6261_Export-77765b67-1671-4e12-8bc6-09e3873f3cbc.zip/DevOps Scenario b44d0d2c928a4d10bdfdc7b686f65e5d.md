# DevOps Scenario

Created by: Ionut
Created time: June 25, 2024 2:43 PM
Tags: Scenario

### Resources

### DevOps Tools (idea for an scenario)

![Untitled](DevOps%20Scenario%20b44d0d2c928a4d10bdfdc7b686f65e5d/Untitled.png)

   | Secret management |

### Tools

### Glossary

https://opus.lib.uts.edu.au/bitstream/10453/130066/1/DevOps- Concepts Practices Tools Benefits and Challenges.pdf#page=6.33 - devops tools per category 

https://www.redhat.com/architect/devops-cicd

https://github.com/sottlmarek/DevSecOps?tab=readme-ov-file#methodologies-whitepapers-and-architecture

| Tool | Description | Helm chart repository | Deployment options |
| --- | --- | --- | --- |
| https://trivy.dev/ | Container Images Security Scanning  | https://artifacthub.io/packages/olm/community-operators/trivy-operator |  |
| https://www.sonarsource.com/products/sonarqube/ | Static Code Analysis (SAST) | https://artifacthub.io/packages/helm/sonarqube/sonarqube |  |
| https://snyk.io/ | SAST and Software Composition Analysis (SCA)  | https://artifacthub.io/packages/helm/snyk/snyk-monitor |  |
| https://about.gitlab.com/ | VCS and Automation Server | https://artifacthub.io/packages/helm/gitlab/gitlab | https://docs.gitlab.com/charts/installation/command-line-options.html |
| https://www.jenkins.io/ | Automation Server (CI/CD pipelines) | https://artifacthub.io/packages/helm/jenkinsci/jenkins |  |
| https://www.openfaas.com/ | Deploy functions and code to Kubernetes | https://artifacthub.io/packages/helm/openfaas/openfaas |  |
| https://www.elastic.co/security | Security Analytics and Visualization | https://github.com/elastic/cloud-on-k8s/tree/main/deploy/eck-stack |  |
| https://www.elastic.co/observability/log-monitoring | Log Management and Monitoring | https://github.com/elastic/cloud-on-k8s/tree/main/deploy/eck-stack |  |
| https://www.zaproxy.org/ | Dynamic Application Security Testing (DAST) | https://artifacthub.io/packages/helm/securecodebox/zap |  |
| https://falco.org/ | Runtime Application Self-Protection (RASP) | https://artifacthub.io/packages/helm/falcosecurity/falco |  |
| https://jfrog.com/artifactory/
https://goharbor.io/ | Container Registry | https://artifacthub.io/packages/helm/jfrog/jfrog-platform
https://artifacthub.io/packages/helm/harbor/harbor |  |
| 
https://fleet.rancher.io/
https://argo-cd.readthedocs.io/en/stable/ | Pull-based approach CD pipeline | https://artifacthub.io/packages/helm/fleet/fleet
https://artifacthub.io/packages/helm/argo/argocd-apps |  |
| https://www.vaultproject.io/ | Parameter Store
Secret Manager | https://artifacthub.io/packages/helm/hashicorp/vault |  |
| https://novu.co/ | Notification |  |  |
| https://www.keycloak.org/ | Identity Management | https://artifacthub.io/packages/helm/bitnami/keycloak |  |
| https://www.openpolicyagent.org/docs/latest/ | Policy Enforcement Agent |  |  |
| https://min.io/ | Object Storage | https://artifacthub.io/packages/helm/bitnami/minio |  |

### ArgoCD

- ‣ - How to install and use ArgoCD for implementing GitOps
- Pulls from repo every 3 minutes.

### GitLab

- Notes and Decisions
    - [x]  Should we use GitLab or find another VCS tool - Use GitLab for now
        
        > When installing GitLab on Kubernetes, there are some trade-offs that you need to be aware of:
        > 
        > - Administration and troubleshooting requires Kubernetes knowledge
        > - It can be more expensive for smaller installations. The default installation requires more resources than a single node Linux package deployment, as most services are deployed in a redundant fashion.
        > - There are some feature [limitations to be aware of.](https://docs.gitlab.com/charts/#limitations)
        > 
        > Use this method if your infrastructure is built on Kubernetes and you’re familiar with how it works. The methods for management, observability, and some concepts are different than traditional deployments. The helm chart method is for Vanilla Kubernetes deployments and the GitLab Operator can be used to deploy GitLab on an OpenShift cluster. The GitLab Operator can be used to automate Day 2 operations in both OpenShift and vanilla Kubernetes deployments.
        > 
        > However, there are some instructions on how to install using helm https://docs.gitlab.com/charts/
        > 
    - [x]  Use the trial version deployment. No need for the production-grade one at the moment
        
        By default, the GitLab chart includes an in-cluster PostgreSQL, Redis, and
        MinIO deployment. Those are for trial purposes only and **not recommended for use in production environments.**
        If you wish to deploy these charts into production under sustained load, you
        should follow the complete [installation guide](https://www.notion.so/gitlab-org/charts/gitlab/-/blob/master/doc/installation/index.md).
        
        The production infrastructure requires that the stateful components, like PostgreSQL or Gitaly (a Git repository storage dataplane), run outside the cluster on PaaS or compute instances. This configuration is required to scale and reliably service the variety of workloads found in production GitLab environments. (E.g. for a capacity of up to 1,000 users or 20 RPS you would need 8 vCPU, 16 GB memory). 
        
    - [ ]  Will we need DinD inside GitLab runner?
        
        By default, the deployment doesn’t come preconfigured for DinD (within GitLab Runner) - (More info here) https://docs.gitlab.com/runner/install/kubernetes.html#running-docker-in-docker-containers-with-gitlab-runner — no idea if we would need it or not.
        
    - [ ]  GitLab consumes a huge amount of resources → difficult to deploy on minikube. It might be possible to separate Gitlab Runner and register it with the official GitLab instance. https://alirezarezvani.medium.com/easy-steps-to-setup-your-own-gitlab-runner-on-gitlab-or-locally-e6618212c442
    - [ ]  Might be worth checking the Jenkins helm chart. A decisive factor for choosing between the two would be how well they integrate with the other applications we target (Snyk, etc…)
- Deployment Options
    
    ![GitLab helm charts hierarchy](DevOps%20Scenario%20b44d0d2c928a4d10bdfdc7b686f65e5d/Untitled%201.png)
    
    GitLab helm charts hierarchy
    
    https://docs.gitlab.com/charts/installation/command-line-options.html
    
- Officially suggested deployment
    
    ```bash
    helm repo add gitlab https://charts.gitlab.io/
    helm repo update
    helm upgrade --install gitlab gitlab/gitlab \
      --timeout 600s \
      --set global.hosts.domain=example.com \  # default
      --set global.hosts.externalIP=10.10.10.10 \ 
      --set certmanager-issuer.email=me@example.com \
      --set postgresql.image.tag=13.6.0 # in config is 14.8.0
    ```
    
- Deployment
    
    
    ```bash
    helm repo add gitlab https://charts.gitlab.io/
    helm repo update
    helm upgrade --install gitlab gitlab/gitlab \
      --timeout 600s \
      --set global.hosts.externalIP=192.168.49.2 \
      --set certmanager-issuer.email=me@example.com
    ```
    
    Problem - Insufficient 
    
    https://containersolutions.github.io/runbooks/posts/kubernetes/0-nodes-available-insufficient/
    
    ```bash
    >>> kubectl describe pod gitlab-webservice-default
    Events:
      Type     Reason            Age                From               Message
      ----     ------            ----               ----               -------
      Warning  FailedScheduling  37m                default-scheduler  0/1 nodes are available: 1 Insufficient cpu. preemption: 0/1 nodes are available: 1 No preemption victims found for incoming pod.
      Warning  FailedScheduling  11m (x9 over 37m)  default-scheduler  0/1 nodes are available: 1 Insufficient cpu. preemption: 0/1 nodes are available: 1 No preemption victims found for incoming pod.
      ...
      Warning  BackOff    2m57s (x125 over 34m)  kubelet            Back-off restarting failed container dependencies in pod gitlab-webservice-default-c896bf779-x8mvs_default(0b5c3832-9025-40b8-a3bc-a910d15ba571)
    
    ```
    
    ```bash
     containers:
          ...
          image: registry.gitlab.com/gitlab-org/build/cng/gitlab-webservice-ee:v17.1.1
            ...
            resources:
              requests:
                cpu: 300m
                memory: 2500M
           image: registry.gitlab.com/gitlab-org/build/cng/gitlab-workhorse-ee:v17.1.1
            ...
            resources:
              requests:
                cpu: 100m
                memory: 100M
          initContainers:
          - image: registry.gitlab.com/gitlab-org/build/cng/certificates:v17.1.1
            imagePullPolicy: IfNotPresent
            name: certificates
            resources:
              requests:
                cpu: 50m
           ...
            image: registry.gitlab.com/gitlab-org/build/cng/gitlab-base:v17.1.1
            imagePullPolicy: IfNotPresent
            name: configure
            resources:
              requests:
                cpu: 50m
            ...
            image: registry.gitlab.com/gitlab-org/build/cng/gitlab-webservice-ee:v17.1.1
            imagePullPolicy: IfNotPresent
            name: dependencies
            resources:
              requests:
                cpu: 50m
            ...
    ```
    
    ```bash
    >>> kubectl describe nodes
    
    Capacity:
      cpu:                2
      ephemeral-storage:  51289568Ki
      hugepages-2Mi:      0
      memory:             8128448Ki
      pods:               110
    Allocatable:
      cpu:                2
      ephemeral-storage:  51289568Ki
      hugepages-2Mi:      0
      memory:             8128448Ki
      pods:               110
    ...
    Allocated resources:
      (Total limits may be over 100 percent, i.e., overcommitted.)
      Resource           Requests          Limits
      --------           --------          ------
      cpu                1975m (98%)       0 (0%)
      memory             3851299712 (46%)  170Mi (2%)
      ephemeral-storage  0 (0%)            0 (0%)
      hugepages-2Mi      0 (0%)            0 (0%)
    ```
    
    ```bash
    Namespace                   Name                                               CPU Requests  CPU Limits  Memory Requests  Memory Limits  Age
      ---------                   ----                                               ------------  ----------  ---------------  -------------  ---
      default                     gitlab-certmanager-674d6c48f9-dmctb                0 (0%)        0 (0%)      0 (0%)           0 (0%)         75m
      default                     gitlab-certmanager-cainjector-cf556df9c-rj2fg      0 (0%)        0 (0%)      0 (0%)           0 (0%)         75m
      default                     gitlab-certmanager-webhook-7d59cbd8f7-brsbp        0 (0%)        0 (0%)      0 (0%)           0 (0%)         75m
      default                     gitlab-gitlab-exporter-78db6d85d6-9vwjk            75m (3%)      0 (0%)      100M (1%)        0 (0%)         75m
      default                     gitlab-gitlab-runner-5b78997d58-wpkfp              0 (0%)        0 (0%)      0 (0%)           0 (0%)         75m
      default                     gitlab-gitlab-shell-6d56c6578d-tpknh               50m (2%)      0 (0%)      6M (0%)          0 (0%)         75m
      default                     gitlab-gitlab-shell-6d56c6578d-wh9ss               50m (2%)      0 (0%)      6M (0%)          0 (0%)         75m
      default                     gitlab-kas-78db44ff6c-2xrjd                        100m (5%)     0 (0%)      100M (1%)        0 (0%)         75m
      default                     gitlab-kas-78db44ff6c-s6n7k                        100m (5%)     0 (0%)      100M (1%)        0 (0%)         75m
      default                     gitlab-minio-7459bf69b-5p2ws                       100m (5%)     0 (0%)      128Mi (1%)       0 (0%)         75m
      default                     gitlab-nginx-ingress-controller-8c5f779cf-plb48    100m (5%)     0 (0%)      100Mi (1%)       0 (0%)         75m
      default                     gitlab-nginx-ingress-controller-8c5f779cf-xtk96    100m (5%)     0 (0%)      100Mi (1%)       0 (0%)         75m
      default                     gitlab-prometheus-server-8dbfc9dc9-nm4g7           0 (0%)        0 (0%)      0 (0%)           0 (0%)         75m
      default                     gitlab-redis-master-0                              0 (0%)        0 (0%)      0 (0%)           0 (0%)         75m
      default                     gitlab-registry-544645d885-jms4j                   50m (2%)      0 (0%)      32Mi (0%)        0 (0%)         75m
      default                     gitlab-registry-544645d885-smvqg                   50m (2%)      0 (0%)      32Mi (0%)        0 (0%)         75m
      default                     gitlab-toolbox-6bd995fd9d-px7zd                    50m (2%)      0 (0%)      350M (4%)        0 (0%)         75m
      default                     gitlab-webservice-default-c896bf779-x8mvs          400m (20%)    0 (0%)      2600M (31%)      0 (0%)         75m
      kube-system                 coredns-7db6d8ff4d-lgbkl                           100m (5%)     0 (0%)      70Mi (0%)        170Mi (2%)     76m
      kube-system                 etcd-minikube                                      100m (5%)     0 (0%)      100Mi (1%)       0 (0%)         21h
      kube-system                 kube-apiserver-minikube                            250m (12%)    0 (0%)      0 (0%)           0 (0%)         21h
      kube-system                 kube-controller-manager-minikube                   200m (10%)    0 (0%)      0 (0%)           0 (0%)         21h
      kube-system                 kube-proxy-68qv2                                   0 (0%)        0 (0%)      0 (0%)           0 (0%)         76m
      kube-system                 kube-scheduler-minikube                            100m (5%)     0 (0%)      0 (0%)           0 (0%)         21h
      kube-system                 storage-provisioner                                0 (0%)        0 (0%)      0 (0%)           0 (0%)         21h
    ```
    
    Memory constrained environments:
    
    - [https://docs.gitlab.com/omnibus/settings/memory_constrained_envs.html](https://docs.gitlab.com/omnibus/settings/memory_constrained_envs.html)

### Gitlab Runner vs Jenkins app integration

| Application | Jenkins | Gitlab |
| --- | --- | --- |
| SonarQubehttps://www.sonarsource.com/products/sonarqube/ | https://docs.sonarsource.com/sonarqube/latest/analyzing-source-code/scanners/jenkins-extension-sonarqube/ | https://docs.sonarsource.com/sonarqube/latest/devops-platform-integration/gitlab-integration/ |
| https://snyk.io/ | https://docs.snyk.io/scm-ide-and-ci-cd-workflow-and-integrations/snyk-ci-cd-integrations/jenkins-plugin-integration-with-snyk | Couldn’t find |
| https://www.zaproxy.org/ | https://plugins.jenkins.io/zap/ | Couldn’t find |
| Http Requests | https://www.jenkins.io/doc/pipeline/steps/http_request/ | curl |
| https://www.vaultproject.io/ | https://plugins.jenkins.io/hashicorp-vault-plugin/ | https://developer.hashicorp.com/hcp/docs/vault-secrets/integrations/gitlab |
| JFrog Artifactoryhttps://jfrog.com/artifactory/ | https://jfrog.com/help/r/jfrog-integrations-documentation/jenkins-artifactory-plug-in | https://jfrog.com/help/r/jfrog-pipelines-documentation/gitlab-integration |

### JFrog Artifactory

[Installing JFrog helm chart](https://jfrog.com/help/r/jfrog-installation-setup-documentation/install-the-jfrog-platform-using-helm-chart)

[Installing Single-Node](https://jfrog.com/help/r/jfrog-installation-setup-documentation/install-artifactory-single-node-with-helm-charts)

```bash
# Enable Artifactory only
xray:
  enabled: false
insight:
  enabled: false
distribution:
  enabled: false
pipelines:
  enabled: false

```

- [ ]  Will the users and the repository have to be configured upon every installation?
Several workarounds:
* install and manually configure the repo. export and write a script to configure the repo on subsequent installations.

### NginX Ingress Controller

Configure a NginX Ingress Controller that will redirect traffic based on the path of the request. This is needed for accessing different applications’ UIs, such as GitLab or Artifactory which reside within the Kubernetes cluster. Given they run on a VM the SSH Tunneling will reach the NginX Controller on port 8080, which will redirect the requests based on the path (`/gitlab`, `/artifactory`). With this configuration I hope I will be able to access the application through a browser from my local machine. 

How to set up a NginX Ingress Controller [here](https://www.youtube.com/watch?v=72zYxSxifpM&t=1849s).

When the nginx-controller service is up, you can start the port forwarding int the following way:

```bash
kubectl -n ingress-nginx port-forward svc/ingress-nginx-controller 8080:80
```

Then, to access it from your machine, use SSH Tunnelling in the following manner:

```bash
ssh  -L 8080:localhost:8080 -i .\.ssh\k8-scenario0 grozai1@k8s-scenario0.cs.aalto.fi
```

Now, if you access [localhost:8080](http://localhost:8080) from the browser, you will connect to the Nginx Ingress Controller.

When deploying target applications, you also need to create the services that would redirect the requests accordingly. Details in [here](https://github.com/marcel-dempers/docker-development-youtube-series/blob/master/kubernetes/ingress/controller/nginx/features/routing-by-path-rewrite.yaml).

### Possible Scenario: End-to-end Kubernetes Factory

- *Kubernetes DevSecOps Pipeline Architecture in Azure*
    
    https://learn.microsoft.com/en-us/azure/architecture/guide/devsecops/devsecops-on-aks
    
    ![*Kubernetes DevSecOps Pipeline Architecture in Azure*](DevOps%20Scenario%20b44d0d2c928a4d10bdfdc7b686f65e5d/Untitled%202.png)
    
    *Kubernetes DevSecOps Pipeline Architecture in Azure*
    
- *Kubernetes DevSecOps Pipeline Architecture in AWS*
    
    https://aws.amazon.com/blogs/devops/building-an-end-to-end-kubernetes-based-devsecops-software-factory-on-aws/
    
    [https://github.com/aws-samples/devsecops-cicd-containers](https://github.com/aws-samples/devsecops-cicd-containers)
    
    ![*Kubernetes DevSecOps Pipeline Architecture in AWS*](DevOps%20Scenario%20b44d0d2c928a4d10bdfdc7b686f65e5d/Untitled%203.png)
    
    *Kubernetes DevSecOps Pipeline Architecture in AWS*
    
- *On-Premise Kubernetes DevSecOps Pipeline Architecture Mirroring the AWS implementation*
    
    https://drive.google.com/file/d/10YMifLTxxDL2Q9Pexhy1lhtdGP79L7hN/view?usp=sharing
    
    ![kubernetes factory.drawio (1).svg](DevOps%20Scenario%20b44d0d2c928a4d10bdfdc7b686f65e5d/kubernetes_factory.drawio_(1).svg)
    
    1. When a user commits the code to GitLab repository, it will trigger the GitLab Pipelines.
    
    2. Secret Scanning Phase:
    
    2a. Sensitive information found --> fail the build & report the vulnerability
    
    3. Building the image and perform SCA and SAST.
    
    3a. Vulnerability --> invoke OpenFaas which processes and posts to Logging and Security Management Systems
    
    3b. Success --> pushes the image to JFrog Artifactory
    
    4. Deploy to Staging environment
    
    5. If deployment is successful, Pipelines triggers the DAST stage, scanning with OWASP Zap
    
    5a. Vulnerability --> invoke OpenFaas --> Logging & Monitoring
    
    6. On Success, the approval stage is triggered, and an email is sent to the approver for action via some Notification Service.
    
    7. After approval, Pipelines deploys the code to the production environment.
    
    8. During the pipeline run, GitLab sends email notifications on the build state to subscribed users through the Notification Service.
    
- Notes
    - Difficulties in configuring all systems.
    - Difficulties in finding test data.
    - Difficulties in finding one-to-one counterparts to the AWS services.
    - The AWS scenario is well documented and the GitHub repo might be helpful when configuring the communication between systems.
    - Another similar blog post here: https://aws.amazon.com/blogs/devops/building-end-to-end-aws-devsecops-ci-cd-pipeline-with-open-source-sca-sast-and-dast-tools/
    - Yet another similar (almost identical) blog post https://www.clickittech.com/devops/devops-architecture/
    - Similar blog posts on Azure:
        - https://learn.microsoft.com/en-us/azure/architecture/solution-ideas/articles/devsecops-infrastructure-as-code
        - https://learn.microsoft.com/en-us/azure/architecture/guide/devsecops/devsecops-on-aks
        - https://learn.microsoft.com/en-us/azure/architecture/guide/aks/aks-cicd-github-actions-and-gitops
    - https://github.com/N4si/DevSecOps-Project - DevSecOps Project to setup Netflix clone on AWS using CICD, Security, Monitoring and GitOps (with yt tutorial 🙂)

### Attack plan

1. Install a VCS tool (GitLab) on k8s cluster. Install NginX Ingress Controller to access GitLab from within a browser.
2. configure a repository containing Wordpress ~~and another one containing the Wordpress deployment configuration~~.
3. ~~Spin up another cluster containing ArgoCD (this would be the staging/production  environment)?~~
4. Install JFrog Artifactory and configure a repository.
5. The GitLab server should be able to spin up pipeline builds on pull-requests (or whenever the Wordpress repo changes). The pipeline can be simple initially, could contain only the deployment phase (whenever code changes in the Wordpress repository, it should send the newly built image to artifactory).
6. Add Secret management.
7. Start adding phases to the pipeline.
    1. Saving to Artifactory.
    2. Secret Scanning.
    3. SCA & SAST.
8. Initially, the stages can just stop the pipeline build on failures.
9. Later you can add the OpenFaas and connect each stage to it.
10. Add the Elastic stack for logging and monitoring.
11. Add the staging environment.
12. Add the DAST stage.
13. add the RASP stage.
14. add manual approval workflow with notification service.

### Multi-environment k8s deployments

https://stackoverflow.com/questions/43212836/multiple-environments-staging-qa-production-etc-with-kubernetes