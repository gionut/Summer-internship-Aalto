# Devops Scenario

# Deploying Gitlab

```bash
# Run GitLab helm chart installation:
helm repo add gitlab https://charts.gitlab.io/
helm repo update
helm upgrade --install gitlab gitlab/gitlab \
--timeout 600s \
--set global.hosts.domain=example.com \
--set global.hosts.externalIP=10.10.10.10 \
--set certmanager-issuer.email=me@example.com \
--set postgresql.image.tag=13.6.0 \
--set prometheus.install=false
# --set globa.edition=ce # for community edition

# Configure port forwarding to ingress controller
kubectl get pods -n default -l app=nginx-ingress
kubectl port-forward gitlab-nginx-ingress-controller-8c5f779cf-5rpll 8080:80 8443:443 -n default

# Get Gitlab root user password: 
kubectl get secret gitlab-gitlab-initial-root-password -ojsonpath='{.data.password}' | base64 --decode ; echo
sm0sWmgdCuUqCNiyXmucUvxEEBzTPcfDrP8bfdaZyDRW6gJJC20djUVWF9dCi1WF
# In the Windows local machine. Add a DNS entry to 
echo *127.0.0.1 gitlab.example.com >> C:\Windows\System32\drivers\etc\hosts
# And a*pply ssh tunnelling:
ssh -L 8080:localhost:8080 -L 8443:localhost:8443 -i .\.ssh\k8-scenario0 [grozai1@k8s-scenario0.cs.aalto.fi](mailto:grozai1@k8s-scenario0.cs.aalto.fi)
```

### Memory constrained env configs

```bash
puma['worker_processes'] = 0

sidekiq['concurrency'] = 10

prometheus_monitoring['enable'] = false

# Couldn't find how to set this one
gitlab_rails['env'] = {
  'MALLOC_CONF' => 'dirty_decay_ms:1000,muzzy_decay_ms:1000'
}

gitaly['configuration'] = {
  concurrency: [
    {
      'rpc' => "/gitaly.SmartHTTPService/PostReceivePack",
      'max_per_repo' => 3,
    }, {
      'rpc' => "/gitaly.SSHService/SSHUploadPack",
      'max_per_repo' => 3,
    },
  ],
  cgroups: {
    repositories: {
      count: 2,
    },
    mountpoint: '/sys/fs/cgroup',
    hierarchy_root: 'gitaly',
    memory_bytes: 500000,
    cpu_shares: 512,
  },
}
gitaly['env'] = {
  'MALLOC_CONF' => 'dirty_decay_ms:1000,muzzy_decay_ms:1000',
  'GITALY_COMMAND_SPAWN_MAX_PARALLEL' => '2'
}

```

```bash
gitlab:
	# sidekiq['concurrency'] = 10
	sidekiq:
		concurrency: 10
	# puma['worker_processes'] = 0 https://gitlab.com/gitlab-org/charts/gitlab/-/blob/master/charts/gitlab/charts/webservice/values.yaml?ref_type=heads#L138
	# not sure if it's this one.
	webserver:
		workerProcesses: 0 
	gitaly:
		shell:
		  concurrency: []
		    - rpc: "/gitaly.SmartHTTPService/PostUploadPack"
			    maxPerRepo: 3
		    - rpc: "/gitaly.SSHService/SSHUploadPack"
		      maxPerRepo: 3
		  repositories:
			  count: 2
			memoryBytes: 500000
	    cpuShares: 512

		
```

### Push Project

```bash
# Create a new project
# Add ssh key to your project

# Use this to communicate with the remote repository

git config --global user.email "gitlab_admin_8ffa86@example.com"
git -c http.sslVerify=false <command>
# Example git -c http.sslVerify=false clone https://gitlab.example.com:8843/root/simple-app.git

#Example; Pushing an existing folder
git init --initial-branch=main
# git remote add origin git@gitlab.example.com:root/simple-app.git -- need to configure port 22 forwarding
git remote set-url origin https://gitlab.example.com:8443/root/simple-app.git
git add .
git commit -m "Initial commit"
git -c http.sslVerify=false push --set-upstream origin main
# you'll need to connect in order to push
```

## Configure Runners

```bash
# Create impersonation access token with the right permissions
# Send the create request and save the runner authentication token from the response
curl.exe -k --request POST --header "PRIVATE-TOKEN: glpat-AD4a9ozbNRa9xNFpo2Gy" --data "runner_type=instance_type" "https://gitlab.example.com:8443/api/v4/user/runners"

# Encode the secret
spare runner instance token: glrt-jSWeEEnycWqW5gUin_Gd
echo "glrt-RTgevkBs5CYP_51ZWHHC" | base64

# Edit the secret manually
kubectl get secrets gitlab-gitlab-runner-secret -o yaml
kubectl edit secrets gitlab-gitlab-runner-secret

# Upgrade the gitlab-runner chart
helm upgrade \
--reuse-values \
--set gitlab-runner.gitlabUrl=http://gitlab-webservice-default:8181 \
--set gitlab-runner.runners.locked=null \
--set gitlab-runner.runners.privileged=true \
--set gitlab-runner.runners.pollTimeout=600 \
--set gitlab-runner.logLevel=debug \
--set gitlab-runner.concurrent=2 \
gitlab gitlab/gitlab 

helm upgrade \
--reuse-values \
-f runner.yml \
gitlab gitlab/gitlab 

# runner.yml -- need to investigate the duplicated values in the runners and config sections
gitlab-runner:
  concurrent: 2
  logLevel: "debug"
  gitlabUrl: "http://gitlab-webservice-default:8181"
  runners:
    locked: null
    privileged: true
    pollTimeout: 600
    url: "http://gitlab-webservice-default:8181"
    cloneUrl: "http://gitlab-webservice-default:8181"
    config: |
      [[runners]]
        url="http://gitlab-webservice-default:8181"
        clone_url="http://gitlab-webservice-default:8181"
        [runners.kubernetes]
          poll_timeout=600
          image = "ubuntu:20.04"
          privileged = true
        [[runners.kubernetes.volumes.secret]]
          name = "dind-certs-docker"
          mount_path = "/etc/docker/certs.d/harbor.harbor/"
        [[runners.kubernetes.volumes.empty_dir]]
          name = "dind-certs"
          mount_path = "/certs/client"
          medium = "Memory"
          
### .gitlab-ci.yml
variables:
  IMAGE_NAME: harbor.harbor/library/demo-app
  IMAGE_TAG: python-app-1.0

stages:
  - build
  - deploy

build_image:
  stage: build
  image: docker:24.0.5
  services:
    - docker:24.0.5-dind
  variables:
    DOCKER_HOST: tcp://docker:2376
    DOCKER_TLS_CERTDIR: "/certs"
    DOCKER_TLS_VERIFY: 1
    # https://gitlab.com/gitlab-org/gitlab-runner/-/issues/4125
    DOCKER_CERT_PATH: "$DOCKER_TLS_CERTDIR/client"
  before_script:
    - docker info
    - echo '6aYF4pxybEXlS9tcwt6M4o6DsY5OH2pf' | docker login https://harbor.harbor -u 'robot$gitlab-robot' --password-stdin''
  script:
    - docker build -t $IMAGE_NAME:$IMAGE_TAG .
    - docker push $IMAGE_NAME:$IMAGE_TAG
```

### Issues

- [x]  gitlab-runner needs to register itself by POSTing to https://gitlab.example.com:8443. The domain is use by the ingress controller, but the k8s dns does not know about it.
Solutions: try using the service name instead !!!! with the exposed port 8181
- [x]  Pipeline build is stuck:
Possible similar issues:
* [https://gitlab.com/gitlab-org/gitlab-runner/-/issues/4884](https://gitlab.com/gitlab-org/gitlab-runner/-/issues/4884)
Possible doc:
*[https://docs.gitlab.com/runner/executors/kubernetes/index.html](https://docs.gitlab.com/runner/executors/kubernetes/index.html)
* https://gitlab.com/gitlab-org/gitlab-runner/-/merge_requests/384
solved by setting pollTimeout=600
- [x]  Runner can’t reach host. Similar to the first issue:
Solved:  add gitlab-runner.runners.url=http://gitlab-webservice-default:8181 and gitlab-runner.runners.urlClone=http://gitlab-webservice-default:8181
- [x]  Job hangs with `Created fresh repository` - associated with not enough resources: https://forum.gitlab.com/t/ci-cd-jobs-failing-today-at-created-fresh-repository/44975/2
- [x]  Server crashes multiple times - I suspect the lack of resources is again the problem here
- [x]  When (eventually) it gets enough resources, it fails with:
    
    ```bash
    fatal: unable to access 'http://gitlab-webservice-default:8181/root/proj.git/': 
    Error while processing content unencoding: incorrect header check
    ERROR: Job failed: command terminated with exit code 1
    ```
    
    Try this https://gitlab.com/gitlab-org/gitlab/-/issues/357462#note_944973503
    
    Adding enough resources solved the problem.
    

# Deploying Harbor Image Registry

[Harbor](https://artifacthub.io/packages/helm/harbor/harbor) is an open source, free Image Registry software.

```bash
helm repo add harbor https://helm.goharbor.io
helm install harbor harbor/harbor \
--create-namespace -n harbor \
--set trivy.enabled=false # will be deployed separately so the vulnerability scanning can happen as a separate step in the pipeline build

helm upgrade --install harbor harbor/harbor -n harbor --reuse-values \
--set expose.type=clusterIP \
--set externalURL=https://harbor.harbor \
--set expose.tls.auto.commonName="harbor.harbor" # it is required

kubectl port-forward --address 0.0.0.0 service/harbor -n harbor 8080:443
# Install a nginx ingress controller and a cert-manager

# Create certsecrets
kubectl get secret -n harbor harbor-nginx -o jsonpath="{.data.ca\.crt}" | base64 --decode > ca.crt
# kubectl get secret -n harbor harbor-nginx -o jsonpath="{.data.tls\.key}" | base64 --decode > harbor.harbor.key
# kubectl get secret -n harbor harbor-nginx -o jsonpath="{.data.tls\.crt}" | base64 --decode > harbor.harbor.crt
# openssl x509 -inform PEM -in harbor.harbor.crt -out harbor.harbor.cert
# kubectl create secret generic dind-certs --from-file=ca.crt=ca.crt --from-file=harbor.harbor.cert=harbor.harbor.cert --from-file=harbor.harbor.key=harbor.harbor.key
kubectl create secret generic dind-certs --from-file=ca.crt=ca.crt
kubectl create secret generic dind-certs-docker --from-file=ca.crt=ca.crt

# Create robot-account and give permissions
6aYF4pxybEXlS9tcwt6M4o6DsY5OH2pf
echo '6aYF4pxybEXlS9tcwt6M4o6DsY5OH2pf' | docker login https://harbor.harbor -u 'robot$gitlab-robot' --password-stdin''
docker pull harbor.harbor/library/python:3.9-slim-buster
docker tag python:3.9-slim-buster harbor.harbor/library/python:3.9-slim-buster
docker push harbor.harbor/library/python:3.9-slim-buster

# test with dind pod
kubectl apply -f dind-pod.yaml
kubectl exec dind-pod -it sh

### dind-pod.yml
apiVersion: v1
kind: Pod
metadata:
  name: dind-pod
spec:
  containers:
    - name: dind-container
      image: docker:24.0.5-dind
      securityContext:
        privileged: true
      volumeMounts:
        - name: certs
          mountPath: /etc/docker/certs.d/harbor.harbor/
      env:
        - name: DOCKER_TLS_CERTDIR
          value: "/etc/docker/certs.d"
  volumes:
    - name: certs
      secret:
        secretName: dind-certs
```

### Issues

https://kubesphere.io/docs/v3.3/devops-user-guide/how-to-integrate/harbor/

https://docs.gitlab.com/ee/ci/docker/authenticate_registry.html

https://docs.gitlab.com/runner/configuration/tls-self-signed.html#kubernetes

https://forum.gitlab.com/t/gitlab-k8s-runner-with-docker-image-from-insecure-registry/63261

https://docs.gitlab.com/ee/ci/docker/using_docker_build.html#use-the-kubernetes-executor-with-docker-in-docker

- Can’t connect to Harbor Registry from a pipeline build: error - unknown ca for harbor_domain
    - [x]  Copy the certificate to `/usr/local/share/ca-certificates/` as instructed in https://docs.gitlab.com/runner/executors/kubernetes/index.html#hostpath-volume
    - [x]  See if can use `image_pull_secrets` — Not OK, this is for authentication, not the TLS connection
        - https://renjithvr11.medium.com/running-gitlab-runners-on-kubernetes-8e7fc9bf75ce
        https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/
        - Issue: https://forum.gitlab.com/t/gitlab-ci-kubernetes-image-pull-secrets-not-respected/25931
    - [x]  Mount the harbor certificate to `/etc/docker/certs.d/harbor.harbor` using `hostPath` volume https://docs.gitlab.com/runner/executors/kubernetes/index.html#hostpath-volume - Error: Failed to initialize: unable to resolve docker endpoint: open /etc/docker/certs.d/harbor.harbor/ca.pem: no such file or directory
    - [x]  Add a `.pem` cert via a `ConfigMap` as detailed in  https://paraspatidar.medium.com/add-ssl-tls-certificate-or-pem-file-to-kubernetes-pod-s-trusted-root-ca-store-7bed5cd683d The Runner pod seems not to contain the file set via volumes
    - [x]  Add the certificate to the local `/usr/local/share/ca-certificates` and restart docker daemon as instructed in [https://docs.gitlab.com/runner/configuration/tls-self-signed.html#x509-certificate-signed-by-unknown-authority-while-trying-to-pull-executor-images-from-private-registry](https://docs.gitlab.com/runner/configuration/tls-self-signed.html#x509-certificate-signed-by-unknown-authority-while-trying-to-pull-executor-images-from-private-registry). Nothing changed…
    - [x]  As per https://forum.gitlab.com/t/gitlab-runner-operator-is-not-able-to-attach-customized-volumes-from-config-toml-to-pods-deployments/92822, all configurations in `config.toml` are applied to every spawned job and not to the runner pod.
    - [x]  Some more info on ssl in dind https://blog.ronnyvdb.net/2019/10/02/gitlab-runner-and-docker-in-docker-dind-configuration/
- Cannot perform an interactive login from a non TTY device
    
    https://stackoverflow.com/questions/73524574/cannot-perform-an-interactive-login-from-a-non-tty-device-error-from-garygrossga
    

## Deploying SonarQube

- Create `alm_setting` for GitLab

```bash
helm repo add sonarqube https://SonarSource.github.io/helm-chart-sonarqube
helm repo update
helm upgrade --install -n gitlab --version '~8' sonarqube sonarqube/sonarqube

# Create ALM Settings
# curl -u admin:admin12345 --request POST http://localhost:9000/api/authentication/login

curl -u admin:admin12345 --request POST http://localhost:9000/api/alm_settings/delete --form "key=gitlab-alm-config"
curl -u admin:admin12345 --request POST http://localhost:9000/api/alm_settings/create_gitlab
--form "key=gitlab-alm-config" --form "personalAccessToken=$PRIVATE_TOKEN" --form url="http://gitlab-chart-nginx-ingress-controller:8181/api/v4"

# Create Project
curl -u admin:admin12345 --request POST http://localhost:9000/api/projects/delete \
--form "project=gitlabproject"
curl -u admin:admin12345 --request POST http://localhost:9000/api/projects/create \
--form "name=GitlabProject" --form "project=gitlabproject"

# Enable SONAR CI/CD Gitlab
$SONAR_TOKEN=$(curl --request POST -u admin:admin12345 http://localhost:9000/api/user_tokens/generate \
--form name=project_token --form type=GLOBAL_ANALYSIS_TOKEN | jq -r '.token')
curl -s --request DELETE --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
              "http://gitlab-chart-webservice-default:8181/api/v4/admin/ci/variables/SONAR_TOKEN"
curl --request POST --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
              "http://gitlab-chart-webservice-default:8181/api/v4/admin/ci/variables" \
                --form "key=SONAR_TOKEN" --form "value=$SONAR_TOKEN" --form "masked=true" --form "protected=false"

SONAR_HOST_URL=http://sonarqube-sonarqube:9000
curl -s --request DELETE --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
              "http://gitlab-chart-webservice-default:8181/api/v4/admin/ci/variables/SONAR_HOST_URL"
curl --request POST --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
              "http://gitlab-chart-webservice-default:8181/api/v4/admin/ci/variables" \
                --form "key=SONAR_HOST_URL" --form "value=$SONAR_HOST_URL" --form "masked=false" --form "protected=false"

# Make sure the project contains the following
Create sonar-project.properties file in git repo with the following content:
sonar.projectKey=gitlabproject
sonar.qualitygate.wait=true

Add the following to the CI pipeline config:
sonarqube-check:
  stage: static_analysis
  image: 
    name: sonarsource/sonar-scanner-cli:latest
    entrypoint: [""]
  variables:
    SONAR_USER_HOME: "${CI_PROJECT_DIR}/.sonar"  # Defines the location of the analysis task cache
    GIT_DEPTH: "0"  # Tells git to fetch all the branches of the project, required by the analysis task
  cache:
    key: "${CI_JOB_NAME}"
    paths:
      - .sonar/cache
  script: 
    - sonar-scanner
  allow_failure: true
  only:
    - master
```

# Deploying Vault

```bash
# Install Vault Chart
helm install vault hashicorp/vault -n gitlab --set server.dev.enabled=true

kubectl create clusterrolebinding oidc-reviewer  \
   --clusterrole=system:service-account-issuer-discovery \
   --group=system:unauthenticated

kubectl exec vault-0 -- vault auth enable jwt
kubectl exec vault-0 -- vault write auth/jwt/config \
   oidc_discovery_url=https://kubernetes.default.svc.cluster.local \
   oidc_discovery_ca_pem=@/var/run/secrets/kubernetes.io/serviceaccount/ca.crt

# Query the jwks_uri specified in /.well-known/openid-configuration
kubectl get --raw "$(kubectl get --raw /.well-known/openid-configuration | jq -r '.jwks_uri' | sed -r 's/.*\.[^/]+(.*)/\1/')"

KEY=$CONVERTED_JWKS_TO_PEM
vault write auth/jwt/config \
   jwt_validation_pubkeys="-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqUfurbkwpUlKKwR9t1Cb\nQCm9Pksk+vpic8ocZ1LZBwCim2Cur+GZQvmp8cwNveha8rI38IWW2+fR0395kUTm\nP5ItkmR++ixeMdTdcH2Hd/jQf6wGLTSujXYUKjLC/JeT2XwBtqyF/o3zfU1wfedR\nEpUQQ0HJgxKRHnvVvS+Oh5hOpk+sEWehkFl653maerFHQuwieKuDvhOyEVv8Ty9n\n4NcLm650SKl00pDkaAd7GVcm+IA34mgSbI3xhtDqQutGc3q//8vClEAPW8owisbm\nFhUPd24X0+RcFalTCXSxecsfHvNRo5AXlEGQCVH3E7zKLwhRH804f1EbGsPuNs79\nEQIDAQAB\n-----END PUBLIC KEY-----"

      
kubectl create token default | cut -f2 -d. | base64 --decode
# OR
kubectl exec my-pod -- cat /var/run/secrets/kubernetes.io/serviceaccount/token | cut -f2 -d. | base64 --decode

vault write auth/jwt/role/my-role \
   role_type="jwt" \
   bound_audiences="https://kubernetes.default.svc.cluster.local" \
   user_claim="sub" \
   bound_subject="system:serviceaccount:default:default" \
   policies="default" \
   ttl="1h"
   
  vault write auth/jwt/role/git-proj \
   role_type="jwt" \
   bound_audiences="https://kubernetes.default.svc.cluster.local" \
   user_claim="sub" \
   bound_subject="project_path:root/project:ref_type:branch:ref:master" \
   policies="default" \
   ttl="1h"

manual_authentication:
  variables:
    VAULT_ADDR: http://vault:8200
  id_tokens:
    VAULT_ID_TOKEN:
      aud: https://kubernetes.default.svc.cluster.local
  before_script:
    - apt-get update && apt-get install -y curl git jq
  script:
    - >
      curl
      --request POST
      --header "X-Vault-Request: true"
      --data "{\"jwt\":\"$VAULT_ID_TOKEN\",\"role\":\"git-proj\"}"
      "http://vault:8200/v1/auth/jwt/login"
      
    
# Exec into vault container
kubectl -n gitlab exec vault-0 -it -- /bin/sh
echo "root" | vault login

# Configure vault server
vault auth enable jwt
vault write auth/jwt/config oidc_discovery_url="http://gitlab-chart-nginx-ingress-controller:8181" bound_issuer="gitlab-chart-nginx-ingress-controller"
```

# Helm

Now that we have a working application with Gitlab, Gitlab Runner and Harbor Registry, I will continue with packaging the three component in a single chart that provides everything is needed for them to run as a whole.

Steps:

---

Step 1 - Completed

---

- Create a Personal Access Token: https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html#create-a-personal-access-token-programmatically using the `toolbox pod` https://docs.gitlab.com/ee/administration/operations/rails_console.html?tab=Helm+chart+(Kubernetes)#starting-a-rails-console-session
    
    ```bash
    sudo gitlab-rails runner "token = User.find_by_username('root').personal_access_tokens.create(scopes: ['admin_mode', 'read_user', 'api', 'read_api'], name: 'Root Token', expires_at: 365.days.from_now); token.set_token('token-string-here123'); token.save!"
    
    ```
    
- *Set root user password secret*. Can be done by setting the `initialRootPassword` value in the gitlab chart. Details: https://docs.gitlab.com/charts/installation/secrets#initial-root-password
- *Install Gitlab*
- *Create a User Impersonation Token*. It can be created via API [Create Impersonation Token](https://docs.gitlab.com/ee/api/users.html#create-an-impersonation-token). *Create a secret containing the impersonation token*.
- *Create a Instance Runner* via the API
    - Code
        
        ```bash
        curl.exe -k --request POST --header "PRIVATE-TOKEN: glpat-AD4a9ozbNRa9xNFpo2Gy" --data "runner_type=instance_type" "https://gitlab.example.com:8443/api/v4/user/runners"
        ```
        
- *Create a secret containing the Instance Runner Authentication Token (IRAT)*

---

Step 2 - Completed!

---

- *Create a secret containing the CA certificate for Harbor* to be used by the Gitlab Runner jobs.  — Use cert-manager to automatically generate and inject certificates.
- *Install Harbor*.  Set the CA certificate as shown in https://github.com/goharbor/harbor-helm/blob/main/values.yaml#L5, or https://github.com/goharbor/harbor-helm/blob/main/values.yaml#L358 or leave empty if generated with cert-manager
- *Create a Robot Account with necessary permissions*. It can be created via API [Create Robot Account](https://github.com/goharbor/harbor/blob/main/api/v2.0/swagger.yaml#L2308). More details in this issue: https://github.com/goharbor/harbor/issues/16884
- *Create a secret containing the Robot Account username and token*. Make it available via environment variables?

---

Step 3 - Completed!

---

- *Install Gitlab Runner*
    - Set the IRAT secret. Could be done by setting the `runnerToken` value in the gitlab-runner chart. Details: https://gitlab.com/gitlab-org/charts/gitlab-runner/-/blob/main/values.yaml#L78 or by updating the secret `runner-secret` to contain the registration token.
    - Set the Harbor CA secret. Could be done by setting the chart values as shown in https://github.com/goharbor/harbor-helm/blob/main/values.yaml#L5
    - Set the docker side CA secret.
    - Create the Robot Account Instance-level variable - Gitlab. Can be managed via API. Can be masked - won’t show in the output. [https://docs.gitlab.com/ee/api/instance_level_ci_variables.html](https://docs.gitlab.com/ee/api/instance_level_ci_variables.html)
    - 

---

Step 4 - Completed!

---

- *Create a gitlab repository*
- Configure the `.gitlab-ci.yaml` to use the robot account for connecting to Harbor.
- Push the project to GitLab.
- Issue docker requires that the repository name contains a “.” or a “:” character. Since harbor is accessed via its service dns name “harbor”, it cannot be used as a valid repository name. [https://www.docker.com/blog/how-to-use-your-own-registry-2/#:~:text=NOTE%3A,our ubuntu image%3A](https://www.docker.com/blog/how-to-use-your-own-registry-2/#:~:text=NOTE%3A,our%20ubuntu%20image%3A)
- Create a job that would clone an external repository containing all the files needed for the Gitlab Runner. Use a Git-Curl image and automate the interaction with the Gitlab Instance: getting the necessary access tokens and creating and pushing the repository. Gitlab, Harbor and Gitlab Runner should be up and running, with the runner ready to process jobs.

[Draw.io Diagram](https://app.diagrams.net/?tags=%7B%7D&lightbox=1&highlight=0000ff&edit=_blank&layers=1&nav=1&title=Untitled%20Diagram.drawio.svg#R%3Cmxfile%3E%3Cdiagram%20name%3D%22Page-1%22%20id%3D%22UvJtl6OuAhh4fJ8T49XT%22%3E5Ztfj6o4FMA%2FjcndBxKgjjqPjjM7M8ndjVGzu2%2BbCh3oDFJTyqj76bdAQaCIoCCY%2B2LgAKX8enr%2B9NQBmG32rxRu7T%2BIiZyBrpr7AXge6PqjNua%2FgeAgBGM9ElgUm5FIOwqW%2BD8khKqQ%2BthEXuZGRojD8DYrNIjrIoNlZJBSssve9kGc7Fu30EKSYGlAR5b%2BjU1mR9LJg3qUvyFs2fGbNVVc2cD4ZiHwbGiSXUoEXgZgRglh0dFmP0NOwC7mEj33%2B4mrSccoclmVB%2BzH9eLVcJ%2Bm%2FvOX8nF4gvBfqohWvqHjiw9e4Q1ysItEp9khJuHt8MaB%2FAJ42tmYoeUWGsGlHR93LrPZxuFnGj%2BkxHdNZIozuZ%2FxSxFlaJ8SiX6%2FIrJBjB74LeLqWCA8JJCj811qRGLudmY0hkIKhRpYSdtHUvxAwKoBTpfAvWLmwPUATLn43fUYDBrJMcySOYNRBlc6hJVpDrM0xzJMTS%2BAOWoL5VhC%2BQbpmtA7QDkaZVlOumapAQmmRA655jSwjPzMJeF8rjF3y7ghM2NLZWopLA8FVGIZRQ5k%2BDtrgYtQiTfMCebdOw7KQ3ZQHsc52h7xqYHEU2mLeaYhPdcOg9RCTGonHLjkqyuN5Xx%2FwCvn7fNluT%2FsPOOfj68%2FhwXzQhpKiw%2FX9krlTnwnXMfNqsXDFz81yWEBstbrReYYTBpQ%2B0JUsjUusRfqJfaidITO24vu0Iwu1qJan1xbi3JeaFjRcgK1LdMpW84ZRZDxQEhdBEGarq7IF3Ijr7REBkWsaadUOoDnlawvTmh4mmTozV0jhOpzfaH9RKiNumb4KDEUSjiHnrcj1MzoYX91srtISHafZVqo%2FnhfTFe%2F9RVj7GqrmskmsBZ2eSJRtcK8R2GBcVQ%2ByVoix7%2BNZfFAB1vckD4bHA%2BHD54CApgn3VNxYYNN0zmVaWY9eeOuWlxVCpLMEx6pJdRahaimkwAw8cFxgF0Q%2F2m3VMr4ZSlSS0S%2FcTjDp4bBFaZsQjcXECZDVlnNCrSsMEBsj528BJRMZcWD%2FZzNNTinp29h5N0aWDkM6sf0HeZC7x7kb9rDeVatzNfhCaj1M7jECjYPp%2BEU7uRH31UOV%2FxpJUHfgqzDADrxBx3lc1qvE7riLstR37O%2FdbiND8mK5VpdnU1DmiMn8BAm%2FuaHVnAY040u8C6krvWU%2BU0zwOI%2ByyngSV0OdXg6f%2B8bzM7g6XJUY4daqhghQ4UGBBV4IjbsR5BT3TmV5CzFnrw17rJrCqoCS3FKKLOJRVzovBylOTrHe34SshX4PxFjB1Edhj4j15R3ouX%2FCulEtL5f9rXRfWfrHpULGtexB78S%2Bzhk7At8OdoXBeFkjan%2F5cxcPDfSu%2FaBeoW8oBc1sKRUeG4NpMUaWIU0oY0cKhmjBnIorTU4lxdT6310GznUuEiP8sXo5lDJwf4CWdhj4TK5nEX9BSmOPrYo9A%2BD0s7ifr36sm9fcq04NDuBPy5X7DDvHneTdljPWExXg2wx6MtfcyVs3M9cS7k7rLqEVRQuaIhU8RDzt%2F2tX9SwsmUFjNEtkwHwSwWksf9tLiANH51SCg%2BpG7bBdiMv1XJu09JQy0UmILctNHe%2Fno9ksvfzg6gHjW5tAnK0PPe9wKAt0JZ4mJGg%2BXuLlyed7xqoUjK8avtfv3b65QdAk7boVd3qJ7WU3zjc8l4%2FcPkaf2M5jZ7b7qipqqzPN05qQIW4vY2kBly0xnnjpAbIkXpVpan30fef1AB5MV04HOia%2FDdZWZ9T8hn%2BjyRwPjxCbNrxlA%2Fk%2FaQp8ZCmqxNO4E5yCN9Wq%2FmybxC7oyaXJbiO9TfrqGEGS7KOSdFUr4%2BYnx7%2FLRU53uNfzsDL%2Fw%3D%3D%3C%2Fdiagram%3E%3C%2Fmxfile%3E)

![Untitled Diagram.drawio.svg](Devops%20Scenario%206828e3b05cde4b75bca50571f9fe6bfc/Untitled_Diagram.drawio.svg)

Gitlab - Gitlab Runner - Harbor Registry Workflow Timeline

### Helmfile

Repository: ‣

```bash
helmfile sync --set repo_token="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"
```

### Gitlab-chart

Chart containing a custom Gitlab release with more predefined values, a service account and a job that creates an Administrator Personal Identification Token which can be further used for managing Gitlab resources, including Instance Runners and Repositories.

### Improvements

- Move service account from the gitlab-subchart to the root templates folder as it is used by all subcharts in the helmfile.
- Give consistent names to sub-charts jobs.
- See if `kubectl` commands inside jobs could be substituted with environment variables
- See if the overall design can simplified.
- Make push-repo job wait for the gitlab job to wait for the Private Token to be registered
- Sometimes the runner tries to set ROBOT_SECRET_ACCOUNT variable before harbor-chart gets to create the token which ends up in the error: Cannot perform an interactive login from a non TTY device